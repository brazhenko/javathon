package com;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.json.JSONObject;
import java.io.*;

// SQL integration
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@Controller
public class feelit {

    // JDBC URL, username and password of MySQL server
    private static final String url = "jdbc:mysql://localhost:3306/userdata";
    private static final String user = "root";
    private static final String password = "YourRootPassword";

    // JDBC variables for opening and managing connection
    private static Connection con;
    private static Statement stmt;


    @GetMapping("/index")
    public String index(){
        return "index";
    }

    @PostMapping("/register")
    public String greeting(@RequestParam(name="uid", required=false, defaultValue="NullUid") String uid, Model modelUid,
                           @RequestParam(name="year", required=false, defaultValue="NullYear") String year, Model modelYear,
                           @RequestParam(name="sex", required=false, defaultValue="NullSex") String sex, Model modelSex,
                           @RequestParam(name="livemode", required=false, defaultValue="0") String lifemode, Model modelMode,
                           @RequestParam(name="foodstyle", required=false, defaultValue="NullFood") String foodstyle, Model modelFood,
                           @RequestParam(name="weight", required=false, defaultValue="NullWeight") String weight, Model modelWeight,
                           @RequestParam(name="height", required=false, defaultValue="NullHeight") String height, Model modelHeight
                            ) {
        //Создание объекта json
        JSONObject obj=new JSONObject();
        modelUid.addAttribute("uid", uid);
        modelYear.addAttribute("year", year);
        modelSex.addAttribute("sex", sex);
        modelMode.addAttribute("lifemode", lifemode);
        modelFood.addAttribute("foodstyle", foodstyle);
        modelWeight.addAttribute("weight", weight);
        modelHeight.addAttribute("height", height);

        //Кодирование объекта json
        obj.put("uid", uid);
        obj.put("sex", sex);

        System.out.println(uid);
        System.out.println(year);
        System.out.println(sex);
        System.out.println(lifemode);
        System.out.println(foodstyle);
        System.out.println(weight);
        System.out.println(height);
        try {
            File file=new File("/Users/andrew/Documents/feelit/src/main/resources/templates/JsonFile1.json");
            if (file.delete()) {
                System.out.println("JsonFile1.json файл удален");
            } else System.out.println("Файла JsonFile1.json не обнаружено");
            file.createNewFile();
            FileWriter fileWriter = new FileWriter(file);
            System.out.println("Writing JSON object to file");
            fileWriter.write(obj.toString());
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String insertQuery = "insert into users (uid, sex, livemode, weight, height, eatmode, year)values(";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(insertQuery);
        stringBuilder.append("'" + uid + "', ");
        stringBuilder.append(sex + ", ");
        stringBuilder.append(lifemode + ", ");
        stringBuilder.append(weight + ", ");
        stringBuilder.append(height + ", ");
        stringBuilder.append(foodstyle + ", ");
        stringBuilder.append(year);
        stringBuilder.append(")");
        System.out.println(stringBuilder.toString());
        try {
            con = DriverManager.getConnection(url, user, password);
            stmt = con.createStatement();
            stmt.executeUpdate(stringBuilder.toString());
        } catch(Exception e) {
            e.printStackTrace();
        }
        return "JsonFile1.json";
    }
}


