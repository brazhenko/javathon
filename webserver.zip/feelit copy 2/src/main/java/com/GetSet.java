package com;

import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.constraints.Null;
import java.lang.Math;

import java.io.*;

// SQL integration
import java.sql.*;
import java.util.ArrayList;


@Controller
public class GetSet {
    // JDBC URL, username and password of MySQL server
    private static final String url = "jdbc:mysql://localhost:3306/userdata";
    private static final String user = "root";
    private static final String password = "YourRootPassword";

    // JDBC variables for opening and managing connection
    private static Connection con;
    private static Statement stmt;
    private static int count;
    private static ResultSet rs;
    private static int id;
    private static int age;
    private static String vit1;
    private static JSONObject temp;
    private static int vit2;
    private static String vit3;

    @PostMapping("/getset")
    @ResponseBody
    public String getSet(@RequestParam(name="uid", required=false, defaultValue="NullUid") String uid, Model modelUid) {

        String query = "select * from users where uid = '" + uid + "'";

        System.out.println((int) (Math.random() * 5));

        System.out.println(query);
        try {
            // opening database connection to MySQL server
            con = DriverManager.getConnection(url, user, password);

            // getting Statement object to execute query
            stmt = con.createStatement();

            // executing SELECT query
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                count = rs.getInt(1);
                age = 2019 - rs.getInt("year");
            }
            System.out.println(age);
            System.out.println(count);
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        } finally {
            //close connection ,stmt and resultset here
            try { con.close(); } catch(SQLException se) { /*can't do anything */ }
            try { stmt.close(); } catch(SQLException se) { /*can't do anything */ }
            try { rs.close(); } catch(SQLException se) { /*can't do anything */ }
        }
        Pack pack = new Pack();
        pack.pack = new ArrayList<>();
        temp = TakeData((int) (Math.random() * 17));
        Vitamin vitamin = new Vitamin();
        vitamin.name = temp.getString("v1");
        vitamin.dose = temp.getInt("m1");
        pack.pack.add(vitamin);
        temp = TakeData((int) (Math.random() * 17));
        vitamin.name = temp.getString("v1");
        vitamin.dose = temp.getInt("m1");
        pack.pack.add(vitamin);
        temp = TakeData((int) (Math.random() * 17));
        vitamin.name = temp.getString("v1");
        vitamin.dose = temp.getInt("m1");
        pack.pack.add(vitamin);
        // Making gson class to return it
        Gson gson = new Gson();
        String json = gson.toJson(pack);
        return json;
    }
    @ResponseBody
    public JSONObject TakeData(int id) {
        String vitaminQuery = "select * from vitamin1 where id = "  + id;
        System.out.println(vitaminQuery);
        try {
            // opening database connection to MySQL server
            con = DriverManager.getConnection(url, user, password);

            // getting Statement object to execute query
            stmt = con.createStatement();

            // executing SELECT query
            rs = stmt.executeQuery(vitaminQuery);

            while (rs.next()) {
                vit1 = rs.getString("vit");
                vit2 = rs.getInt("w");
                JSONObject obj = new JSONObject();
                obj.put("v1", vit1);
                obj.put("m1", vit2);
                // obj.put("v3", vit3);
                return (obj);
            }
            System.out.println(age);
            System.out.println(count);
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        } finally {
            //close connection ,stmt and resultset here
            try { con.close(); } catch(SQLException se) {  }
            try { stmt.close(); } catch(SQLException se) {  }
            try { rs.close(); } catch(SQLException se) {  }
        }
        JSONObject obj = new JSONObject();
        return  obj;
    }
}