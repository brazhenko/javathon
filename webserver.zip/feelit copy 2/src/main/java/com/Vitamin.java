package com;

public class Vitamin {
    String name;
    int dose;
}
